from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager

driverChrome = webdriver.Chrome(ChromeDriverManager().install())
driverChrome.get("https://www.fortbendcountytx.gov/")
driverChrome.maximize_window()
# start the testing process
# headers
driverChrome.find_element_by_partial_link_text("Property Taxes").click()
driverChrome.save_screenshot("Property.png")
driverChrome.find_element_by_partial_link_text("County Records Research").click()
driverChrome.save_screenshot("County Records Research.png")
driverChrome.find_element_by_partial_link_text("Pay Online").click()
driverChrome.save_screenshot("Pay Online.png")
driverChrome.find_element_by_partial_link_text("Employment").click()
driverChrome.save_screenshot("Employment.png")
# footer links
driverChrome.find_element_by_partial_link_text("Privacy Policy").click()
driverChrome.save_screenshot("Privacy Policy.png")
driverChrome.find_element_by_partial_link_text("Disclaimers").click()
driverChrome.save_screenshot("Disclaimers.png")
driverChrome.find_element_by_partial_link_text("Title VI").click()
driverChrome.save_screenshot("Title VI.png")
# body links
driverChrome.find_element_by_partial_link_text("Services").click()
driverChrome.save_screenshot("Services.png")
driverChrome.find_element_by_partial_link_text("Adopt or Foster a Pet").click()
driverChrome.save_screenshot("Adopt.png")
driverChrome.find_element_by_partial_link_text("Community Development").click()
driverChrome.save_screenshot("Community Development.png")

driverChrome.quit()
# Edge Reports
driverEdge = webdriver.Edge(EdgeChromiumDriverManager().install())
driverEdge.get("https://www.fortbendcountytx.gov/")
# to maximize the browser window
driverEdge.maximize_window()
# headers
driverEdge.find_element_by_partial_link_text("Property Taxes").click()
driverEdge.save_screenshot("PropertyE.png")
driverEdge.find_element_by_partial_link_text("County Records Research").click()
driverEdge.save_screenshot("County Records ResearchE.png")
driverEdge.find_element_by_partial_link_text("Pay Online").click()
driverEdge.save_screenshot("Pay OnlineE.png")
driverEdge.find_element_by_partial_link_text("Employment").click()
driverEdge.save_screenshot("EmploymentE.png")
# footer links
driverEdge.find_element_by_partial_link_text("Privacy Policy").click()
driverEdge.save_screenshot("Privacy PolicyE.png")
driverEdge.find_element_by_partial_link_text("Disclaimers").click()
driverEdge.save_screenshot("DisclaimersE.png")
driverEdge.find_element_by_partial_link_text("Title VI").click()
driverEdge.save_screenshot("Title VIE.png")
# body links
driverEdge.find_element_by_partial_link_text("Services").click()
driverEdge.save_screenshot("ServicesE.png")
driverEdge.find_element_by_partial_link_text("Adopt or Foster a Pet").click()
driverEdge.save_screenshot("AdoptE.png")
driverEdge.find_element_by_partial_link_text("Community Development").click()
driverEdge.save_screenshot("Community DevelopmentE.png")


driverEdge.quit()